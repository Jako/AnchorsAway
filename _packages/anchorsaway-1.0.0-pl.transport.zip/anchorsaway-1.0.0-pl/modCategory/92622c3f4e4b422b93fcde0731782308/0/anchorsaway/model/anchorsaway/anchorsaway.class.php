<?php
/**
 * AnchorsAway
 *
 * Copyright 2021 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package anchorsaway
 * @subpackage classfile
 */

require_once dirname(dirname(__DIR__)) . '/vendor/autoload.php';

/**
 * Class AnchorsAway
 */
class AnchorsAway extends \TreehillStudio\AnchorsAway\AnchorsAway
{
}
