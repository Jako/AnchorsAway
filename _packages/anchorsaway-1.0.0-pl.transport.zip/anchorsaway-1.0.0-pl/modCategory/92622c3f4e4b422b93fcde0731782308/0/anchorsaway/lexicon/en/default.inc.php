<?php
/**
 * Default Lexicon Entries for AnchorsAway
 *
 * @package anchorsaway
 * @subpackage lexicon
 */
$_lang['anchorsaway.log_message'] = 'Replaced [[+count]] anchor links on the resource [[+id]].';
