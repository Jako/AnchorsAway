<?php
/**
 * Setting Lexicon Entries for AnchorsAway
 *
 * @package anchorsaway
 * @subpackage lexicon
 */
$_lang['setting_anchorsaway.add_data_anchor'] = 'Add data-anchor';
$_lang['setting_anchorsaway.add_data_anchor_desc'] = 'Add data-anchor attribute to the link.';
$_lang['setting_anchorsaway.debug'] = 'Debug';
$_lang['setting_anchorsaway.debug_desc'] = 'Log debug information in the MODX error log.';
